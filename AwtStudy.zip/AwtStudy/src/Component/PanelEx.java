package Component;

import java.awt.Button;
import java.awt.Color;
import java.awt.FlowLayout;
import java.awt.Frame;
import java.awt.Label;
import java.awt.Panel;
import java.awt.TextField;

public class PanelEx extends Frame{
	Button btn1, btn2;
	Label lab1, lab2;
	TextField tf1, tf2;
	
	PanelEx(){
		super("Log In");
		this.setSize(300, 500);
		this.setLayout(new FlowLayout());
		
		Panel p1 = new Panel();
		p1.setBackground(Color.cyan);
		
		Panel p2 = new Panel();
		p2.setBackground(Color.cyan);
		
		this.add(p1);	this.add(p2);
		
		lab1 = new Label("ID");
		tf1 = new TextField(20);
		btn1 = new Button();
		p1.add(lab1);	p1.add(tf1);	p1.add(btn1);
		
		lab2 = new Label("PASSWORD");
		tf2 = new TextField(20);
		btn2 = new Button();
		p2.add(lab2);	p2.add(tf2);	p2.add(btn2);
	}
	public static void main(String[] args) {
		PanelEx p = new PanelEx();
		p.setVisible(true);
	}
}