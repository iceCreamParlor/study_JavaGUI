package Component;

import java.awt.Dimension;
import java.awt.Frame;
import java.awt.Toolkit;

public class FrameEx{
	public static void main(String[] args) {
		Frame f = new Frame();
		f.setSize(400, 400);
		Toolkit tk = Toolkit.getDefaultToolkit(); //ȭ�� ��ü�� ũ�� ���ϱ�
		Dimension screenSize = tk.getScreenSize();
		System.out.println(screenSize);
		f.setLocation(screenSize.width/2-200, screenSize.height/2-200);
		f.setVisible(true);
	}
}