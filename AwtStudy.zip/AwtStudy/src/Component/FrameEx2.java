package Component;
import java.awt.Button;
import java.awt.Checkbox;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Frame;
import java.awt.Label;
import java.awt.TextArea;
import java.awt.TextField;
import java.awt.Toolkit;

public class FrameEx2 extends Frame{
	Button btn;
	TextField tf1, tf2, tf3, tf4;
	TextArea ta1, ta2;
	Checkbox ch1, ch2;
	Label lab1, lab2;
	
	public FrameEx2() {
		super("Frame Component Test");
		this.setSize(300, 300);
		Toolkit tk = Toolkit.getDefaultToolkit();
		Dimension screenSize = tk.getScreenSize();
		this.setLocation(screenSize.width/2 - 150, screenSize.height/2-150);
		this.setLayout(new FlowLayout()); //���ʿ��� ���������� �����ϸ� ���̾ƿ� ����
		
		btn = new Button("Ȯ��");
		btn.setSize(100, 50);
		btn.setLocation(100, 125);
		btn.setBackground(new Color(255, 255, 255));
		this.add(btn);
		
		tf1 = new TextField(20);
		this.add(tf1);
		tf2 = new TextField(20);
		this.add(tf2);
		tf3 = new TextField("Hello Human �ȳ��ϼ��� �ݰ����ϴ�", 50);
		this.add(tf3);
		tf4 = new TextField(20);
		this.add(tf4);
		
		ta1 = new TextArea(10, 10);
		this.add(ta1);
		
		ch1 = new Checkbox();
		this.add(ch1);
		
		lab1 = new Label("lab1");
		lab1.setBackground(Color.cyan);
		this.add(lab1);
	}
	public static void main(String[] args) {
		FrameEx2 f = new FrameEx2();
		f.setVisible(true);
	}
}