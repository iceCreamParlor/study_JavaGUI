package event;

public class InnerClassEx2 {
	public static void main(String[] args) {
		Outer1 ot1 = new Outer1();
		Outer1.Inner in = ot1.new Inner();
		in.InnerFunc();
	}
}
class Outer1{
	int value= 100;
	class Inner{
		int value= 200;
		
		void InnerFunc() {
			int value = 300;
			System.out.println("InnerFunc�� value = "+ value);
			System.out.println("Inner Class ���� value = "+ this.value); // this �� InnerClass�� �ǹ�
			System.out.println("Outer1 Class�� value = "+ Outer1.this.value);
		}
	}
}
