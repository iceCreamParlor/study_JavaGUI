package event;

import java.awt.Checkbox;
import java.awt.CheckboxGroup;
import java.awt.Color;
import java.awt.FlowLayout;
import java.awt.Frame;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;

public class ItemEventEx extends Frame {
	CheckboxGroup gp;
	Checkbox chkb1, chkb2, chkb3;
	
	ItemEventEx(){
		super("ItemEvent Test");
		this.setLayout(new FlowLayout());
		this.setBounds(100, 100, 300, 300);
		gp = new CheckboxGroup();
		chkb1 = new Checkbox("������", gp, true);
		chkb2 = new Checkbox("�Ķ���", gp, false);
		chkb3 = new Checkbox("�����", gp, false);
		
		chkb1.addItemListener(new EventHandler());
		chkb2.addItemListener(new EventHandler());
		chkb3.addItemListener(new EventHandler());
		
		this.setBackground(Color.yellow);
		this.add(chkb1);this.add(chkb2);this.add(chkb3);
		this.setVisible(true);
	}
	
	class EventHandler implements ItemListener{
		public void itemStateChanged(ItemEvent e) {
			Checkbox chkb = (Checkbox)e.getSource();
			String str = chkb.getLabel();
			if(str.equals("������")) {
				ItemEventEx.this.setBackground(Color.red);
				chkb1.setBackground(Color.red);
				chkb2.setBackground(Color.red);
				chkb3.setBackground(Color.red);
			}
			else if(str.equals("�Ķ���")) {
				ItemEventEx.this.setBackground(Color.blue);
				chkb1.setBackground(Color.blue);
				chkb2.setBackground(Color.blue);
				chkb3.setBackground(Color.blue);
			}
			else if(str.equals("�����")) {
				ItemEventEx.this.setBackground(Color.yellow);
				chkb1.setBackground(Color.yellow);
				chkb2.setBackground(Color.yellow);
				chkb3.setBackground(Color.yellow);
			}
		}
	}
	public static void main(String[] args) {
		ItemEventEx iee = new ItemEventEx();
	}
}
