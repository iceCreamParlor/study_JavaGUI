package event;

import java.awt.Frame;
import java.awt.event.WindowEvent;
import java.awt.event.WindowListener;

public class WinEventEx extends Frame implements WindowListener{
	WinEventEx(){
		super("WiindowEvent Test");
		this.addWindowListener(this);
		this.setBounds(100, 100, 300, 300);
		this.setVisible(true);
	}
	public void windowActivated(WindowEvent we) {
		
	}
	public void windowDeactivated(WindowEvent we) {
		
	}
	public void windowOpened(WindowEvent we) {
		
	}
	public void windowClosed(WindowEvent we) {
		System.exit(0);
	}
	public void windowClosing(WindowEvent we) {	//X ���߸� ������ ��
		System.exit(0);
	}
	public void windowIconified(WindowEvent we) {	//�ּ�ȭ
		
	}
	public void windowDeiconified(WindowEvent we) {		//�ִ�ȭ
		
	}
	
	public static void main(String[] args) {
		WinEventEx win = new WinEventEx();
	}
}
