package event;

import java.awt.Button;
import java.awt.Frame;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class AnonymousEx extends Frame {
	Button btn;
	public AnonymousEx() {
		btn = new Button("exit");
		this.add(btn, "South");
		this.setBounds(200, 200, 300, 300);
		btn.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent ae) {
				System.exit(0);
			}
		});	//Anonymous Class ��� : �Ʒ��� ���� ������ Ŭ������ ����� �ͺ��� �ڵ尡 ª������.
		
		this.setVisible(true);
	}
	public static void main(String[] args) {
		AnonymousEx ae = new AnonymousEx();
	}
}
//class EventHandler implements ActionListener{
//	public void actionPerformed(ActionEvent ae) {
//		System.exit(0);
//	}
//}
