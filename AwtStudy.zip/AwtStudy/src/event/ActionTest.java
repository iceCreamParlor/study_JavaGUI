package event;

import java.awt.Frame;
import java.awt.Panel;
import java.awt.TextArea;
import java.awt.TextField;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class ActionTest extends Frame implements ActionListener {
	TextField tf;
	TextArea ta;
	
	public ActionTest() {
		super();
		//this.setLayout(new FlowLayout());
		
		tf = new TextField(30);
		tf.requestFocus();// Ŀ���� ��ġ�ϰ� ����
		
		ta = new TextArea(30, 30);
		ta.setFocusable(false); //Ŀ���� ��ġ���� ���ϰ� ����
		ta.setEditable(false); // �������� ���ϰ� ����
		
		this.add(tf, "South"); this.add(ta, "Center");
		tf.addActionListener(this);
		
		this.setBounds(200, 200, 300, 300);
		this.setVisible(true);
	}
	public static void main(String[] args) {
		ActionTest at = new ActionTest();
	}
	public void actionPerformed(ActionEvent ae) {
		String str = ta.getText() + "\n";
		str = str + tf.getText();
		tf.setText("");
		ta.setText(str);
	}
}
