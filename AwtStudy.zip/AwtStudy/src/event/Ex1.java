package event;
import java.awt.CardLayout;
import java.awt.Color;
import java.awt.Component;
import java.awt.Frame;
import java.awt.Panel;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;

public class Ex1 extends Frame implements MouseListener {
	Panel p1 = new Panel();
	Panel p2 = new Panel();
	Panel p3 = new Panel();
	Panel p4 = new Panel();
	CardLayout card = new CardLayout();
	
	public Ex1(){
		super("Event Test");
		this.setLayout(card);
		this.setBounds(300, 300,300, 400);
		p1.setBackground(Color.yellow);
		p2.setBackground(Color.cyan);
		p3.setBackground(Color.gray);
		p4.setBackground(Color.green);
		this.add("1", p1);this.add("2", p2);this.add("3", p3);this.add("4",p4);
		
		p1.addMouseListener(this); // p1�� mouselistener�� ������� �־�� �Ѵ�. eventhandler �� this (���� ��ü)�̴�.
		p2.addMouseListener(this);
		p3.addMouseListener(this);
		p4.addMouseListener(this);
		
	}
	public void mouseClicked(MouseEvent e) {
		Component panel = (Component)e.getSource();
		card.show(this, panel.getName());
	}
	public void mouseEntered(MouseEvent e) {
		
	}
	public void mouseExited(MouseEvent e) {
		
	}
	public void mousePressed(MouseEvent e) {
		
	}
	public void mouseReleased(MouseEvent e) {
		
	}
	public static void main(String[] args) {
		Ex1 e = new Ex1();
		e.setVisible(true);
	}
}
