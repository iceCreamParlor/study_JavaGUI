package event;

import java.awt.Button;
import java.awt.Checkbox;
import java.awt.CheckboxGroup;
import java.awt.Frame;
import java.awt.GridLayout;
import java.awt.Label;
import java.awt.Scrollbar;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class ChkEventEx extends Frame {
	Label label1, label2, result;
	Checkbox[] cb = new Checkbox[4];
	Checkbox[] cb2 = new Checkbox[4];

	CheckboxGroup gp;
	String[] cbName = new String[]{ "����", "������", "����", "��ȭ����" };
	String[] cbName2 = new String[]{ "10��", "20��", "30��", "40��" };
	
	Button btn = new Button("Result");
	
	public ChkEventEx() {
		super();
		this.setBounds(100, 100, 200, 400);
		this.setLayout(new GridLayout(12,1));
		label1 = new Label("����� ��̴� �����Դϱ�?");
		this.add(label1);
		
		for(int i=0; i<4; i++) {
			cb[i] = new Checkbox( cbName[i] );
			this.add(cb[i]);
		}
		label2 = new Label("����� ������?");
		this.add(label2);
		
		gp = new CheckboxGroup();
		for(int i=0; i<4; i++) {
			cb2[i] = new Checkbox( cbName2[i], gp, false );
			this.add(cb2[i]);
		}
		result = new Label("");
		this.add(btn);
		this.add(result);
		this.setVisible(true);
		
		btn.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent ae) {
				String str= "";	String str2= ", ����� ������ ";
				for(int i=0; i< 4; i++) {
					if(cb[i].getState() )	str += cb[i].getLabel() + " ";
					if(cb2[i].getState() )	str2 += cb2[i].getLabel();
				}
				result.setText("����� ����� "+ str + str2 + "�Դϴ�.") ;
			}
		});
	}
	
	public static void main(String[] args) {
		ChkEventEx c = new ChkEventEx();
	}
}
