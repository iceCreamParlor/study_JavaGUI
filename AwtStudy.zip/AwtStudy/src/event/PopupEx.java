package event;

import java.awt.Color;
import java.awt.Frame;
import java.awt.MenuItem;
import java.awt.Point;
import java.awt.PopupMenu;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;

public class PopupEx extends Frame {
	PopupMenu popmenu;
	MenuItem miCopy, miCut, miPaste;
	public PopupEx() {
		super("Popup Test");
		this.setBounds(100, 100, 500, 500);
		
		popmenu = new PopupMenu();
		this.add(popmenu);
		
		miCopy = new MenuItem("����");
		miCut = new MenuItem("�߶󳻱�");
		miPaste = new MenuItem("�ٿ��ֱ�");
		
		popmenu.add(miCopy);
		popmenu.add(miCut);
		popmenu.add(miPaste);
		
		//popup menu��  mouse event
		this.addMouseListener(new EventHandler());
	}
	class EventHandler implements MouseListener{
		public void mouseClicked(MouseEvent e) {
			Point po = e.getPoint();
			if(e.getButton()== e.BUTTON3) // button 1: ���� button2: ��� ��
				popmenu.show(PopupEx.this, po.x, po.y);
			
		}
		public void mouseEntered(MouseEvent e) {
			PopupEx.this.setBackground(Color.yellow);
		}
		public void mouseExited(MouseEvent e) {
			
		}
		public void mousePressed(MouseEvent e) {
			
		}
		public void mouseReleased(MouseEvent e) {
			
		}
	}
	public static void main(String[] args) {
		PopupEx pop = new PopupEx();
		pop.setVisible(true);
	}
}
