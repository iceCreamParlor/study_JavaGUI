package event;

import java.awt.Color;
import java.awt.FileDialog;
import java.awt.Frame;
import java.awt.GridLayout;
import java.awt.Label;
import java.awt.Menu;
import java.awt.MenuBar;
import java.awt.MenuItem;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class MenuTest extends Frame{
	MenuBar menubar;
	Menu bgColor, fontColor, file, tool;
	MenuItem miOpen, miSave, miExit, miBlack, miGray, fontWhite, fontRed;
	Label label;
	
	MenuTest(){
		super();
		//this.setLayout(new GridLayout(1, 10));
		this.setBounds(200, 200, 300, 300);
		this.setVisible(true);
		
		menubar = new MenuBar();
		this.setMenuBar(menubar);
		
		
		
		file = new Menu("File");
		tool = new Menu("Tool");
		menubar.add(file);menubar.add(tool);
		
		miOpen = new MenuItem("Open");
		miExit = new MenuItem("Exit");
		miBlack = new MenuItem("Black");
		miGray = new MenuItem("Gray");
		fontWhite = new MenuItem("White");
		fontRed = new MenuItem("Red");
		bgColor = new Menu("Background Color");
		fontColor = new Menu("Font Color");
		bgColor.add(miBlack);	bgColor.add(miGray);
		fontColor.add(fontWhite);	fontColor.add(fontRed);	//�ڿ� ������ ������ �־�����.
		
		file.add(miOpen);	
		file.addSeparator();	//�޴� �� ���м� �߱�
		file.add(miExit);
		tool.add(bgColor);
		tool.add(fontColor);
		label = new Label("�޴� �׽�Ʈ�ϱ�", Label.CENTER);
		label.setForeground(Color.red);
		this.add(label);
		
		miExit.addActionListener(new EventHandler());
		miOpen.addActionListener(new EventHandler());
		miBlack.addActionListener(new EventHandler());
		miGray.addActionListener(new EventHandler());
		
		
	}
	class EventHandler implements ActionListener{
		Color bgcolor = Color.white;
		Color fcolor = Color.black;
		
		public void actionPerformed(ActionEvent ae) {
			Object obj = ae.getSource();
			if(obj == miOpen) {
				//FileDialog
				FileDialog fd = new FileDialog(MenuTest.this);
				fd.setVisible(true);
			}else if(obj == miExit) {
				System.exit(0);
			}else if(obj == miBlack) {
				//MenuTest.this.setBackground(Color.black);
				bgcolor = Color.black;
			}else if(obj == miGray) {
				//MenuTest.this.setBackground(Color.gray);
				bgcolor = Color.gray;
			}else if(obj == fontWhite) {
				//MenuTest.this.label.setForeground(Color.black);
				fcolor = Color.white;
			}else if(obj == fontRed) {
				MenuTest.this.label.setForeground(Color.red);
				fcolor = Color.red;
			}
			MenuTest.this.setBackground(bgcolor);
			MenuTest.this.label.setForeground(fcolor);
		}
	}
	public static void main(String[] args) {
		MenuTest m = new MenuTest();
	}
}
