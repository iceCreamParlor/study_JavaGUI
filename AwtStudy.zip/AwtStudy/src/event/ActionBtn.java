package event;

import java.awt.Button;
import java.awt.Color;
import java.awt.Frame;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class ActionBtn extends Frame implements ActionListener {
	Button btn1, btn2, btn3;
	public ActionBtn() {
		super("ActionBtn Test");
		this.setLayout(new GridLayout(2,2,30,30));
		this.setBounds(200, 200, 300, 300);
		
		btn1 = new Button("Red");
		btn2 = new Button("Green");
		btn3 = new Button("Blue");
		this.add(btn1);this.add(btn2);this.add(btn3);
		btn1.addActionListener(this);
		btn2.addActionListener(this);
		btn3.addActionListener(this);
	}
	public void actionPerformed(ActionEvent ae ) {
		String str = ae.getActionCommand(); //��ư�� ���ڿ��� ��ȯ
		if(str.equals("Red")) {
			System.out.println(btn1.getBackground());
			if(btn1.getBackground().equals(Color.red)){
				btn1.setBackground(new Color(240, 240, 240));
			}
			else btn1.setBackground(Color.red);
		}else if(str.equals("Green")) {
			btn2.setBackground(Color.green);
		}else if(str.equals("Blue")) {
			btn3.setBackground(Color.blue);
		}
	}
	public static void main(String[] args) {
		ActionBtn a = new ActionBtn();
		a.setVisible(true);
	}
}
